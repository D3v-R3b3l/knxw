import React from 'react';
import { Helmet } from 'react-helmet-async';

const DEFAULT_STRUCTURED_DATA = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "knXw",
  "applicationCategory": "BusinessApplication",
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "USD"
  },
  "description": "Psychographic intelligence platform for understanding user behavior"
};

export default function SEOHead({
  title = "knXw - Universal Intelligence Layer",
  description = "Psychographic intelligence that understands why users do what they do—across web, mobile, games, and any digital environment.",
  keywords = "psychographic intelligence, user analytics, behavioral analysis, AI insights, customer intelligence",
  ogImage = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688aa91c44a8979a009301be/e67a8a337_txpknxwlogo.png",
  ogType = "website",
  canonicalUrl,
  structuredData
}) {
  const fullTitle = title.includes('knXw') ? title : `${title} | knXw`;
  const jsonLd = structuredData || DEFAULT_STRUCTURED_DATA;
  
  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={ogType} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={ogImage} />
      <meta property="og:site_name" content="knXw" />
      
      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={ogImage} />
      
      {/* Canonical URL */}
      {canonicalUrl && <link rel="canonical" href={canonicalUrl} />}
      
      {/* SEO Enhancements */}
      <meta name="robots" content="index, follow" />
      <meta name="author" content="knXw" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      
      {/* Structured Data for Search Engines */}
      <script type="application/ld+json">
        {JSON.stringify(jsonLd)}
      </script>
    </Helmet>
  );
}