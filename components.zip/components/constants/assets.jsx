export const ASSETS = {
  logo: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/688aa91c44a8979a009301be/e67a8a337_txpknxwlogo.png",
  brandName: "knXw",
  // Add more assets as needed
};